'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class project extends Model {
    static associate(models) {              // new ...
      project.belongsTo(models.user, {
        foreignKey: 'userId',
        onDelete: 'CASCADE'
      })
    }                                       // ... new
  }
  project.init({
    userId: DataTypes.INTEGER,
     title: DataTypes.STRING     
  }, {
    sequelize,
    modelName: 'project',
  });
  return project;
};
